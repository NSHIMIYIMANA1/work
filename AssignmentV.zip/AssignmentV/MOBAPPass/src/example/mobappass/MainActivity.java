package example.mobappass;

import android.app.Activity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends Activity {
	TextView ctxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ctxt =(TextView) findViewById(R.id.txtcxt);
        registerForContextMenu(ctxt);
        @SuppressWarnings("unused")
		TextView ctxt= (TextView) findViewById(R.id.txtcxt);
        Button pit=(Button) findViewById(R.id.bexit);
 pit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				finish();
				System.exit(0);
				
				
			}
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
    	switch (item.getItemId()) {
		case R.id.select:
			//
			
			//break;
		case R.id.bcloses:
			
			finish();
			System.exit(0);

		default:
			return super.onOptionsItemSelected(item);
		}
    }

@Override
public void onCreateContextMenu(ContextMenu menu, View v,
		ContextMenuInfo menuInfo) {
	// TODO Auto-generated method stub
	super.onCreateContextMenu(menu, v, menuInfo);
	MenuInflater inflater = getMenuInflater();
	inflater.inflate(R.menu.main ,menu);
	}
@Override
public boolean onContextItemSelected(MenuItem item)
{
	 switch (item.getItemId())
     {
     case R.id.bcloses:
   	  finish();
			System.exit(0);
			default:
			return super.onContextItemSelected(item);
     }}

}
