/** Automatically generated file. DO NOT MODIFY */
package com.v.venn2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}